const surahList = document.getElementById("surahList");
const reader = document.getElementById("reader");
const search = document.getElementById("search");
const backBtn = document.getElementById("backBtn");
const surahTitle = document.getElementById("surahTitle");
const ayahsDiv = document.getElementById("ayahs");
const audio = document.getElementById("audio");

let surahs = [];

async function loadSurahs() {
  surahList.innerHTML = "<p>جاري تحميل السور...</p>";
  const res = await fetch("https://api.alquran.cloud/v1/surah");
  const data = await res.json();
  surahs = data.data;
  showSurahs(surahs);
}

function showSurahs(list) {
  surahList.innerHTML = "";
  list.forEach(surah => {
    const div = document.createElement("div");
    div.className = "card";
    div.innerHTML = `
      <h3>${surah.number}. ${surah.name}</h3>
      <span>${surah.englishName} — عدد الآيات: ${surah.numberOfAyahs}</span>
    `;
    div.onclick = () => openSurah(surah.number, surah.name, surah.englishName);
    surahList.appendChild(div);
  });
}

async function openSurah(number, name, englishName) {
  surahList.classList.add("hidden");
  reader.classList.remove("hidden");
  search.classList.add("hidden");
  surahTitle.textContent = `${name} - ${englishName}`;
  ayahsDiv.innerHTML = "<p>جاري تحميل الآيات...</p>";

  const textRes = await fetch(`https://api.alquran.cloud/v1/surah/${number}/ar.alafasy`);
  const textData = await textRes.json();

  audio.src = textData.data.ayahs[0].audio;
  ayahsDiv.innerHTML = "";

  textData.data.ayahs.forEach(ayah => {
    const p = document.createElement("div");
    p.className = "ayah";
    p.innerHTML = `<small>${ayah.numberInSurah}</small> ${ayah.text}`;
    ayahsDiv.appendChild(p);
  });

  localStorage.setItem("lastSurah", number);
}

backBtn.onclick = () => {
  reader.classList.add("hidden");
  surahList.classList.remove("hidden");
  search.classList.remove("hidden");
};

search.addEventListener("input", () => {
  const q = search.value.trim();
  const filtered = surahs.filter(s =>
    s.name.includes(q) ||
    s.englishName.toLowerCase().includes(q.toLowerCase())
  );
  showSurahs(filtered);
});

loadSurahs();
